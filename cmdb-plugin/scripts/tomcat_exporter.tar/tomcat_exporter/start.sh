#!/bin/sh

nohup java -javaagent:/scripts/tomcat_exporter/jmx_prometheus_javaagent-0.10.jar=18081:/scripts/tomcat_exporter/config.yaml > /dev/null 2>&1 &
